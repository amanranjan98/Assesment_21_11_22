import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conntact-us',
  templateUrl: './conntact-us.component.html',
  styleUrls: ['./conntact-us.component.css']
})
export class ConntactUsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
